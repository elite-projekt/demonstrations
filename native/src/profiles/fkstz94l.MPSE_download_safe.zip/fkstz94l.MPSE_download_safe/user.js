user_pref("browser.startup.homepage_override.mstone", "ignore");
user_pref("browser.startup.couldRestoreSession.count", "0");
user_pref("browser.sessionstore.resuming_after_os_restart", "false");
user_pref("browser.sessionstore.restore_on_demand", "false");
user_pref("browser.sessionstore.resume_session_once", "false");
user_pref("browser.sessionstore.resume_from_crash", "false");
user_pref("browser.sessionstore.restore_tabs_lazily", "false");